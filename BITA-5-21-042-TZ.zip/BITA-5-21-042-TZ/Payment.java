public class Payment extends Books{
	private int cust_id;
	private String cust_Name;
	private String billaddress;
	public Payment(){
	}

	public Payment(int bookID,int bookPrice,String bookAuthor,int cust_id,String cust_Name,String billaddress){
		super(bookID, bookPrice,bookAuthor);
		this.cust_id = cust_id;
		this.cust_Name = cust_Name;
		this.billaddress = billaddress;
	}

	public void setcust_id(int cust_id){
		this.cust_id = cust_id;
	}
	public int getcust_id(){
		return cust_id;
	}
	public void setcust_Name(String cust_Name){
		this.cust_Name = cust_Name;
	}
	public String getcust_Name(){
		return cust_Name;
	}
	public void setbilladdress(String billaddress){
		this.billaddress = billaddress;
	}
	public String getbilladdress(){
		return billaddress;
	}
	public String toString(){
		return  "Payment information"+super.toString()+"paymentcust_id is"+cust_id+"cust_Name is"+cust_Name+
		"billaddress is"+billaddress;
	}
	public static void main(String[] args) {
		Payment muni = new Payment();
        muni.setcust_id(055);
		muni.setcust_Name("khamis");
		muni.setbilladdress("Tanga");
		//muni.getcust_id(022);
		//muni.getcust_Name();
		//muni.getbilladdress();
		muni.setbookID(022);                                        
        muni.setbookPrice(11000);
        muni.setbookAuthor("THE BLACK CARMIT");
        System.out.println(muni.toString());
    }
}
