public class Books{
	private int bookID;
	private int bookPrice;
	private String bookAuthor;
public Books(){

}
public Books(int bookID,int bookPrice,String bookAuthor){
	this.bookID = bookID;
	this.bookPrice = bookPrice;
	this.bookAuthor = bookAuthor;
}
public void setbookID(int bookID){
	this.bookID = bookID;
}
public int getbookID(){
	return bookID;
}
public void setbookPrice(int bookPrice){
	this.bookPrice = bookPrice;
}
public int setbookPrice(){
	return bookPrice;
}
public void setbookAuthor(String bookAuthor){
	this.bookAuthor = bookAuthor;
}
public String getbookAuthor(){
	return bookAuthor;
}
public String toString(){
	return "books details"+bookID+"Price of book"+bookPrice+"bookAuthor is "+bookAuthor;
}
}
