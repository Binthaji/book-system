public class User2 extends Books{
	private String email;
	private String passward;
	private String name;
	private String address;
	private  int phone;
	public User2(){

	}
	public User2(int bookID,int bookPrice,String bookAuthor,String email,String passward, 
		String name, String address, int phone){
		super(bookID,bookPrice,bookAuthor);
		this.email = email;
		this.passward = passward;
		this.name = name;
		this.address = address;
		this.phone = phone;
	}
	public void setemail(String email){
		this.email = email;
	}
	public String getemail(){
		return email;
	}
	public void setpassward(String passward){
		this.passward = passward;
	}
	public String getpassward(){
		return passward;
	}
	public void setname(String name){
		this.name = name;
	}
	public String getname(){
		return name;
	}
	public void setaddress(String address){
		this.address = address;
	}
	public String getaddress(){
		return address;
	}
	public void setphone(int phone){
		this.phone = phone;
	}
	public int getphone(){
		return phone;
	}
	public String toString(){
		return  "User information"+super.toString()+"User_email is"+email+"passward is"+passward+
		"the name is"+name+"User_address is"+address+"my phone is"+phone;
	}
	public static void main(String[] args) {
		User2 muni = new User2();
		muni.setemail("alikhatib@gmail.com");
		muni.setpassward("45328");
		muni.setname("aliy");
		muni.setaddress("kangani");
		muni.setphone(773831027);
		/*muni.getUser_email();
		muni.getUser_passward();
		muni.getUser_address();
		muni.getUser_name();*/
		muni.setbookID(077);                                        
        muni.setbookPrice(80000);
        muni.setbookAuthor("ALIBABA");
		System.out.println(muni.toString());
	}
}
	
