public class Order extends Books{
	private int order_no,item_no,amount;
	public Order(){

	}
	public Order(int bookID,int bookPrice,String bookAuthor,int order_no, int item_no,int amount){
		super(bookID,bookPrice,bookAuthor);
		this.order_no = order_no;
		this.item_no = item_no;
		this. amount = amount;
	}
	public void setorder_no(int order_no){
		this.order_no = order_no;
	}
	public int getorde_no(){
		return order_no;
	}
	public void setitem_no(int item_no){
		this.item_no = item_no;
	}
	public int getitem_no(){
		return item_no;
	}
	public void setamount(int amount){
		this.amount = amount;
	}
	public int getamount(){
		return amount;
	}
	public String toString(){
		return "Order imformation"+super.toString()+"Order number is"+order_no+"item_no is"+item_no+"the amount is "
		+amount;
	}
	public static void main(String[] args) {
		Order muni = new Order();
		muni.setbookID(1);
		muni.setbookPrice(5000);
		muni.setbookAuthor("Amina");
		muni.setorder_no(5);
		muni.setitem_no(6);
		muni.setamount(2000);
		//muni.getBookID();
		//muni.getbookPrice();
		//muni.getbookAuthor();
		muni.setbookID(066);                                        
        muni.setbookPrice(5000);
        muni.setbookAuthor("SEMZABA");
		System.out.println(muni.toString());
	}
}



