public class Customer extends Books{
	private int cust_id;
	private int Payment;
	public Customer(){

	}
	public Customer(int bookID,int bookPrice,String bookAuthor,int cust_id,int Payment){
		super(bookID,bookPrice, bookAuthor);
		this.cust_id = cust_id;
		this.Payment = Payment;
	}

	public void setcust_id(int cust_id){
		this.cust_id = cust_id;
	}
	public int getcust_id(){
		return cust_id;
	}
	public void setPayment(int Payment){
		this.Payment = Payment;
	}
	public int getPayment(){
		return Payment;
	}
	public String toString(){
		return  "Customerinformation"+super.toString()+"Customercust_id is"+cust_id+"CustomerPayment is"+Payment;
	}
	public static void main(String[] args) {
		Customer muni = new Customer();
		muni.setcust_id(001);
		muni.setPayment(7000);
		//muni.getcust_id();
		//muni.getPayment();
		muni.setbookID(222);
        muni.setbookPrice(99000);
        muni.setbookAuthor("HAWA THE BUS DRIVER");
        System.out.println(muni.toString());
    }
}
